# Ev Düzeni – Android uygulaması

Bu klasör, Ev Düzeni uygulamasının Android projesidir. APK'yı iki yoldan biriyle oluşturabilirsin.

## Yol 1: Android Studio (bilgisayarda)

1. Android Studio'yu kur: https://developer.android.com/studio
2. Bu klasörü aç: **File > Open > EvDuzeni**.
3. İlk açılışta gereken parçaları kendisi indirir; birkaç dakika bekle.
4. Menüden **Build > Build App Bundle(s) / APK(s) > Build APK(s)** seç.
5. Bitince çıkan bildirimde **locate**'e tıkla. APK dosyası şurada olur:
   `app/build/outputs/apk/debug/app-debug.apk`

## Yol 2: GitHub (bilgisayara bir şey kurmadan)

1. github.com'da ücretsiz hesap aç ve yeni bir depo (repository) oluştur.
2. **Add file > Upload files** ile bu klasörün içindeki her şeyi yükle
   (`.github` klasörü dahil; görünmüyorsa gizli dosyaları göster).
3. Yükleme bitince **Actions** sekmesinde "APK oluştur" işi kendiliğinden başlar (5-10 dakika).
4. İş yeşil tikle bitince içine gir, en alttaki **EvDuzeni-apk** dosyasını indir.
   İndirilen zip'in içinde APK var.

## Telefona kurma

1. APK'yı telefona gönder (Drive, WhatsApp, kablo…).
2. Dosyaya dokun. Telefon "bilinmeyen kaynak" uyarısı verirse o uygulamaya
   (Dosyalar, Chrome vb.) kurulum izni ver.
3. Kur ve aç. 125 görevin yüklü olarak gelir.

## Bilmen gerekenler

- Görevler **yalnızca telefonda** saklanır. claude.ai'deki web sürümüyle eşitlenmez.
- Uygulamayı silmeden veya telefon değiştirmeden önce **Görevler > Yedek > Yedeği paylaş**
  ile yedek al (Drive'a veya kendine mesaj olarak gönderebilirsin).
  Yeni telefonda **Yedekten geri yükle**'ye bu metni yapıştırman yeterli.
- Telefonun geri tuşu açık pencereyi kapatır, sonra Bugün ekranına döner.
